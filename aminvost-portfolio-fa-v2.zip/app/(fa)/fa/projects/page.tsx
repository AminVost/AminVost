import type { Metadata } from "next";
import { ProjectBrowser } from "@/components/project-browser";
import { projectsFa } from "@/data/projects-fa";

export const metadata: Metadata = {
  title: "پروژه‌ها",
  description: "آرشیو پروژه‌های امین اسدی‌ وسطٰی در حوزه وب، موبایل، هوش مصنوعی، دسکتاپ و سیستم‌های Production.",
};

export default function PersianProjectsPage() {
  return (
    <div className="shell">
      <header className="page-hero">
        <div className="eyebrow">آرشیو پروژه‌ها</div>
        <h1>فقط پروژه‌های ویترینی نیستند.</h1>
        <p>پروژه‌های منتخب برای یک نگاه سریع خوب‌اند، اما تصویر کامل‌تر مهم است. اینجا پروژه‌های مشتری، شخصی، قدیمی‌تر و آزمایشی را بدون شلوغ‌کردن صفحه اصلی نگه داشته‌ام.</p>
      </header>
      <ProjectBrowser projects={projectsFa} locale="fa" />
      <div style={{ height: 80 }} />
    </div>
  );
}
