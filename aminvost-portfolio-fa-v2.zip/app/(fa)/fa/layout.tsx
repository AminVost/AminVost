import type { Metadata } from "next";
import type { ReactNode } from "react";
import "../../globals.css";
import { SiteHeader } from "@/components/site-header";
import { Footer } from "@/components/footer";
import { profileFa } from "@/data/profile-fa";
import { anta, manrope } from "../../fonts";

export const metadata: Metadata = {
  metadataBase: new URL(profileFa.domain),
  title: { default: `${profileFa.name} â€” ${profileFa.title}`, template: `%s â€” ${profileFa.shortName}` },
  description: profileFa.headline,
  alternates: { canonical: "/fa", languages: { en: "/", fa: "/fa" } },
  openGraph: { type: "website", url: `${profileFa.domain}/fa`, title: `${profileFa.name} â€” ${profileFa.title}`, description: profileFa.headline, siteName: "Amin Vosta Portfolio", locale: "fa_IR" },
};

export default function PersianLayout({ children }: Readonly<{ children: ReactNode }>) {
  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning className={`${manrope.variable} ${anta.variable}`}>
      <body className="locale-fa">
        <SiteHeader locale="fa" />
        <main className="site-main">{children}</main>
        <Footer locale="fa" />
      </body>
    </html>
  );
}
