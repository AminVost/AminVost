import type { MetadataRoute } from "next";
import { projects } from "@/data/projects";
import { profile } from "@/data/profile";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = profile.domain;
  const staticRoutes = ["", "/projects", "/resume", "/fa", "/fa/projects", "/fa/resume"];
  const projectRoutes = projects.flatMap((project) => [
    `/projects/${project.slug}`,
    `/fa/projects/${project.slug}`,
  ]);
  return [...staticRoutes, ...projectRoutes].map((route) => ({
    url: `${base}${route}`,
    lastModified: new Date(),
    changeFrequency: route.includes("projects/") ? "monthly" : "weekly",
    priority: route === "" || route === "/fa" ? 1 : 0.8,
  }));
}
