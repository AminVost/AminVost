import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Amin Vosta — Software Engineer",
    short_name: "Amin Vosta",
    description: "Personal engineering portfolio of Amin Asadi Vosta.",
    start_url: "/",
    display: "standalone",
    background_color: "#f7f8fa",
    theme_color: "#15171b",
  };
}
