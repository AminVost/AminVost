import type { Metadata } from "next";
import type { ReactNode } from "react";
import "../globals.css";
import { SiteHeader } from "@/components/site-header";
import { Footer } from "@/components/footer";
import { profile } from "@/data/profile";
import { anta, manrope } from "../fonts";

export const metadata: Metadata = {
  metadataBase: new URL(profile.domain),
  title: { default: `${profile.name} â€” ${profile.title}`, template: `%s â€” ${profile.shortName}` },
  description: profile.headline,
  applicationName: "Amin Vosta Portfolio",
  alternates: { canonical: "/", languages: { en: "/", fa: "/fa" } },
  openGraph: { type: "website", url: profile.domain, title: `${profile.name} â€” ${profile.title}`, description: profile.headline, siteName: "Amin Vosta Portfolio" },
  twitter: { card: "summary_large_image", title: `${profile.name} â€” ${profile.title}`, description: profile.headline },
};

export default function EnglishLayout({ children }: Readonly<{ children: ReactNode }>) {
  return (
    <html lang="en" dir="ltr" suppressHydrationWarning className={`${manrope.variable} ${anta.variable}`}>
      <body className="locale-en">
        <SiteHeader locale="en" />
        <main className="site-main">{children}</main>
        <Footer locale="en" />
      </body>
    </html>
  );
}
