import type { Metadata } from "next";
import { ProjectBrowser } from "@/components/project-browser";
import { projects } from "@/data/projects";

export const metadata: Metadata = {
  title: "Projects",
  description: "A complete project archive across web, mobile, AI, desktop and production systems.",
};

export default function ProjectsPage() {
  return (
    <div className="shell">
      <header className="page-hero">
        <div className="eyebrow">Project archive</div>
        <h1>Work, not just a highlight reel.</h1>
        <p>Selected projects are useful, but the full picture matters too. This archive keeps the smaller, older, client and experimental work visible without making the homepage noisy.</p>
      </header>
      <ProjectBrowser projects={projects} />
      <div style={{ height: 80 }} />
    </div>
  );
}
