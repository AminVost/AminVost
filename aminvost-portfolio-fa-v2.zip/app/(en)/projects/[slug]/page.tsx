import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { projects } from "@/data/projects";

export function generateStaticParams() {
  return projects.map((project) => ({ slug: project.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const project = projects.find((item) => item.slug === slug);
  if (!project) return {};
  return { title: project.title, description: project.summary };
}

export default async function ProjectDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const project = projects.find((item) => item.slug === slug);
  if (!project) notFound();

  return (
    <article className="project-detail shell">
      <div className="project-detail-grid">
        <div>
          <Link className="text-link" href="/projects">← Back to projects</Link>
          <div className="project-meta" style={{ marginTop: 28, marginBottom: 16 }}>
            {project.categories.map((item) => <span className="pill" key={item}>{item}</span>)}
          </div>
          <h1>{project.title}</h1>
          <p className="lead">{project.summary}</p>

          <section className="detail-block">
            <h2>What I did</h2>
            <p style={{ color: "var(--muted)", marginTop: 0 }}>{project.contribution || "Project development and implementation work across the listed scope."}</p>
          </section>

          <section className="detail-block">
            <h2>Highlights</h2>
            <ul>{project.highlights.map((item) => <li key={item}>{item}</li>)}</ul>
          </section>

          <section className="detail-block">
            <h2>Technology</h2>
            <div className="tags">{project.technologies.map((tech) => <span className="tag" key={tech}>{tech}</span>)}</div>
          </section>
        </div>

        <aside className="detail-side">
          <dl className="detail-panel">
            <dt>Period</dt><dd>{project.period || "—"}</dd>
            <dt>Role</dt><dd>{project.role || "Software Developer"}</dd>
            {project.context && <><dt>Context</dt><dd>{project.context}</dd></>}
          </dl>
          {project.url && <a className="button primary" href={project.url} target="_blank" rel="noreferrer">Visit live project ↗</a>}
          <Link className="button" href="/resume">See full resume</Link>
        </aside>
      </div>
    </article>
  );
}
