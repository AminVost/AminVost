import Link from "next/link";
import { profile } from "@/data/profile";
import { featuredProjects, projects } from "@/data/projects";
import { ProjectCard } from "@/components/project-card";

export default function HomePage() {
  const selected = featuredProjects.slice(0, 7);
  const personJsonLd = {
    "@context": "https://schema.org",
    "@type": "Person",
    name: profile.name,
    url: profile.domain,
    email: `mailto:${profile.email}`,
    jobTitle: profile.title,
    homeLocation: { "@type": "Place", name: profile.location },
    sameAs: [profile.github],
    knowsAbout: ["Next.js", "React", "React Native", "TypeScript", "PHP", "Applied AI", "OCR", "Qwen", "PWA"],
  };
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(personJsonLd) }} />
      <section className="hero shell">
        <div className="eyebrow"><span className="dot" /> Full-stack software engineer</div>
        <h1>Web, mobile & <span>practical AI.</span></h1>
        <div className="hero-copy">
          <p>{profile.headline} I care about useful product decisions, clean interfaces and software that holds up in production.</p>
          <div className="hero-actions">
            <Link className="button primary" href="/projects">Explore projects <span aria-hidden="true">↗</span></Link>
            <Link className="button" href="/resume">View resume</Link>
          </div>
        </div>
        <div className="stats">
          <div className="stat"><strong>6+ yrs</strong><span>professional development</span></div>
          <div className="stat"><strong>{projects.length}</strong><span>documented projects</span></div>
          <div className="stat"><strong>iOS / Android</strong><span>React Native + PWA</span></div>
          <div className="stat"><strong>AI + Local</strong><span>APIs, OCR & local models</span></div>
        </div>
      </section>

      <section className="section shell selected-work-section">
        <div className="selected-work-head">
          <div>
            <div className="eyebrow">Selected projects</div>
            <h2>A few projects from different parts of my work.</h2>
          </div>
          <div className="selected-work-side">
            <p>Web, mobile, AI and production systems — selected to show the range of problems I’ve worked on.</p>
            <Link className="text-link" href="/projects">See all {projects.length} projects <span aria-hidden="true">→</span></Link>
          </div>
        </div>
        <div className="project-grid">
          {selected.map((project, index) => <ProjectCard key={project.slug} project={project} large={index === 0} index={index} />)}
        </div>
      </section>

      <section className="section shell" id="focus">
        <div className="section-head">
          <div><div className="eyebrow">Focus</div><h2>What I actually work on.</h2></div>
          <p>My background is broad, but these are the areas I keep coming back to in real projects.</p>
        </div>
        <div className="focus-grid">
          {profile.focusAreas.map((area) => (
            <article className="focus-card" key={area.title}>
              <div className="eyebrow">{area.eyebrow}</div>
              <h3>{area.title}</h3>
              <p>{area.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section shell">
        <div className="split">
          <div>
            <div className="eyebrow">How I work</div>
            <h2>Simple ideas. Careful execution.</h2>
          </div>
          <div className="stack">
            {profile.principles.map((item) => <article className="stack-card" key={item.title}><h3>{item.title}</h3><p>{item.text}</p></article>)}
            <article className="stack-card"><h3>Rust, without pretending it is my main stack</h3><p>{profile.rustNote}</p></article>
          </div>
        </div>
      </section>

      <section className="section shell">
        <div className="section-head">
          <div><div className="eyebrow">Experience</div><h2>Long-running production work.</h2></div>
        </div>
        <div className="timeline">
          {profile.experience.map((item) => (
            <article className="timeline-item" key={item.company}>
              <div className="timeline-time">{item.period}</div>
              <div>
                <h3>{item.company}</h3><h4>{item.role}</h4><p>{item.text}</p>
                <ul>{item.bullets.slice(0, 4).map((bullet) => <li key={bullet}>{bullet}</li>)}</ul>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="section shell">
        <div className="section-head">
          <div><div className="eyebrow">Stack</div><h2>Tools I use in context.</h2></div>
          <p>No giant logo wall. These are grouped by the kind of work I use them for.</p>
        </div>
        <div className="skills">
          {profile.skillGroups.map((group) => (
            <div className="skill-row" key={group.label}><strong>{group.label}</strong><div className="tags">{group.items.map((item) => <span className="tag" key={item}>{item}</span>)}</div></div>
          ))}
        </div>
      </section>

      <section className="shell cta" id="contact">
        <div>
          <h2>Have a product problem worth solving?</h2>
          <p>{profile.availability}. I’m also interested in practical AI-assisted product work.</p>
        </div>
        <div className="hero-actions">
          <a className="button primary" href={`mailto:${profile.email}`}>Email me</a>
          <a className="button" href={profile.github} target="_blank" rel="noreferrer">GitHub</a>
        </div>
      </section>
    </>
  );
}
